import { Component, OnInit } from '@angular/core';
import { CommentsService } from '../services/comments.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  title='comments';
  comments:any[];
  userId:number;
  message="";

  constructor(private cs:CommentsService,private route:ActivatedRoute) {

    console.log("CommentsComp created...."+this.userId);
   }

  ngOnInit() {

    this.route.queryParams.subscribe(params=>{
      this.userId=params.postId;
    })
    console.log("commentsComp initialized...."+this.userId);

    if(this.userId)
    this.getAllCommentsByPostId();
    else
    this.getAllComments();


    }

ngOnDestroy(){
  console.log("commentsComp destroyed...."+this.userId);
}
  

    getAllComments(){
      this.cs.getAllComments().subscribe(response=>this.comments=response,error=>this.message=error);
      }

      getAllCommentsByPostId(){
        this.cs.getAllCommentsByPostId(this.userId).subscribe(response=>this.comments=response,error=>this.message=error);
        }

}
