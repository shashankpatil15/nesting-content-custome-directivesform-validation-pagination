import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-components',
  templateUrl: './nested-components.component.html',
  styleUrls: ['./nested-components.component.css']
})
export class NestedComponentsComponent implements OnInit {


  title='Nested Component Demo';

  constructor() { }

  ngOnInit() {
  }

}
