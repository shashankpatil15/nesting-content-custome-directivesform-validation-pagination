import { Directive } from '@angular/core';

@Directive({
  selector: '[fgColor]'
})
export class FgColorDirective {

  constructor() { }

}
